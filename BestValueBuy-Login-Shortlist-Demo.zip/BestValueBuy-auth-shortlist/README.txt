BestValueBuy frontend demo Login + login-required Shortlist

COPY THESE FILES INTO YOUR PROJECT:
- src/utils/demoAuth.js       -> frontend/src/utils/demoAuth.js (new file)
- src/pages/Login.jsx         -> frontend/src/pages/Login.jsx (replace)
- src/pages/Register.jsx      -> frontend/src/pages/Register.jsx (replace)
- src/pages/Shortlist.jsx     -> frontend/src/pages/Shortlist.jsx (replace)
- src/styles/auth-shortlist.css -> frontend/src/styles/auth-shortlist.css (new file)

The existing App.jsx should already have routes for /login, /register, and /shortlist. Keep your existing routes and navbar component. If routes are missing, add:
<Route path="/login" element={<Login />} />
<Route path="/register" element={<Register />} />
<Route path="/shortlist" element={<Shortlist />} />

IMPORTANT: login/register are a FRONTEND DEMO only. Credentials are stored in localStorage in plain text and are not secure. Never use real passwords. This is not production authentication.

SHORTLIST INTEGRATION (required for heart buttons to save):
In Properties.jsx, import:
import { getCurrentUser, toggleShortlist } from '../utils/demoAuth';
import { useNavigate } from 'react-router-dom';

Inside the component that renders the property cards, use:
const navigate = useNavigate();

Replace the current UI-only heart button handler with a handler like:
const handleShortlistClick = (event, propertyId) => {
  event.preventDefault();
  event.stopPropagation();
  if (!getCurrentUser()) {
    navigate('/login', { state: { from: '/shortlist' } });
    return;
  }
  toggleShortlist(propertyId);
};

Then use onClick={(event) => handleShortlistClick(event, property.id)} on the existing heart button. Keep its existing className and markup to preserve styling.

Do the same in PropertyDetails.jsx for its shortlist heart/button. Do not replace whole Properties.jsx or PropertyDetails.jsx with generic files; preserve their existing filters, gallery, rental/sale logic and styling.

NAVBAR LOGIN STATE:
The existing header should listen for the custom event 'bvb-auth-change' and read getCurrentUser() to show the user's name and a Logout action. Import getCurrentUser and logoutDemoUser from '../utils/demoAuth' (adjust relative path if Header.jsx is elsewhere). Since the current Header source wasn't available in the project files provided for this package, do not replace the header. Add the state/event listener around its existing Login link instead.

My Properties and Post Property protection is not automatically changed by this package; add a login guard to those pages only if you want to require sign-in before accessing them. The user asked to preserve their current functionality, so this package does not rewrite those pages.

Existing old shortlist key 'bestValueBuyShortlist' is not automatically migrated. New per-user lists are stored separately under bestValueBuyShortlist:<encoded-email>.
